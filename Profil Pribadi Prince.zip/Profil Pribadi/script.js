// sementara tampilkan alert
document.querySelector(".menu-btn").addEventListener("click", () => {
  alert("Blom ada fitur nya");
});